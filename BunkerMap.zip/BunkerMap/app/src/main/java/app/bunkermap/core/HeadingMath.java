package app.bunkermap.core;

/** Pure math for turning a sensor rotation matrix into a walking direction. No Android imports. */
public final class HeadingMath {
    /** Horizontal length of the phone's back-vector above which the phone counts as "held upright". */
    private static final double UPRIGHT_SWITCH = 0.5;

    private HeadingMath() {}

    /**
     * @param r 3x3 row-major matrix from SensorManager.getRotationMatrixFromVector
     *          (device to world; world X = east-ish, Y = north-ish, Z = up).
     * @return walking direction in radians, clockwise from world +Y, in [-pi, pi); NaN if the input is
     *         invalid or the phone points straight up/down so no horizontal direction exists.
     */
    public static double heading(float[] r) {
        if (r == null || r.length < 9) return Double.NaN;
        for (int i = 0; i < 9; i++) {
            if (!Float.isFinite(r[i])) return Double.NaN;
        }
        // Back of the phone (device -Z) in world coordinates: -(r[2], r[5], r[8]).
        double backE = -r[2];
        double backN = -r[5];
        double e;
        double n;
        if (Math.hypot(backE, backN) >= UPRIGHT_SWITCH) {
            e = backE;
            n = backN;
        } else {
            // Phone lying roughly flat: use the top edge (device +Y) = (r[1], r[4], r[7]).
            e = r[1];
            n = r[4];
        }
        if (Math.hypot(e, n) < 1e-6) return Double.NaN;
        return Math.atan2(e, n);
    }

    /** Wraps an angle to [-pi, pi). */
    public static double wrapPi(double a) {
        double t = (a + Math.PI) % (2 * Math.PI);
        if (t < 0) t += 2 * Math.PI;
        return t - Math.PI;
    }

    /** Clock position 1..12 for a direction relative to straight ahead (clockwise positive); 12 = ahead, 6 = behind. */
    public static int clockPosition(double relativeRad) {
        int h = (int) Math.round(relativeRad / (Math.PI / 6));
        h = ((h % 12) + 12) % 12;
        return h == 0 ? 12 : h;
    }
}
