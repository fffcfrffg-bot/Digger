package app.bunkermap;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import java.util.List;
import java.util.Locale;

import app.bunkermap.core.Track;

/** Draws the track: grid, path, labelled marks, current position with heading arrow, line to the entrance, scale bar. */
public final class MapView extends View {
    private static final double[] NICE_METERS = {1, 2, 5, 10, 20, 50, 100, 200, 500, 1000};

    private final float density;
    private final Paint gridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pathPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dashPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint barPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final ScaleGestureDetector scaleDetector;

    private Track track;
    private float scale = 20f; // pixels per meter
    private double centerX;
    private double centerY;
    private boolean follow = true;
    private double liveHeadingMap = Double.NaN; // radians clockwise from map up; NaN = unknown
    private float lastTouchX;
    private float lastTouchY;

    public MapView(Context context) {
        super(context);
        density = context.getResources().getDisplayMetrics().density;

        gridPaint.setColor(0xFF1E2A1E);
        gridPaint.setStrokeWidth(1f * density);

        pathPaint.setColor(0xFF39FF14);
        pathPaint.setStyle(Paint.Style.STROKE);
        pathPaint.setStrokeWidth(3f * density);
        pathPaint.setStrokeJoin(Paint.Join.ROUND);
        pathPaint.setStrokeCap(Paint.Cap.ROUND);

        dashPaint.setColor(0xFF00BFFF);
        dashPaint.setStyle(Paint.Style.STROKE);
        dashPaint.setStrokeWidth(2f * density);
        dashPaint.setPathEffect(new DashPathEffect(new float[]{12f * density, 8f * density}, 0f));

        textPaint.setTextSize(14f * density);
        barPaint.setColor(Color.WHITE);
        barPaint.setStrokeWidth(2f * density);

        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                float s = scale * detector.getScaleFactor();
                scale = Math.max(2f, Math.min(400f, s));
                invalidate();
                return true;
            }
        });
    }

    public void setTrack(Track t) {
        track = t;
        invalidate();
    }

    public void setLiveHeading(double mapHeadingRad) {
        liveHeadingMap = mapHeadingRad;
    }

    public void setFollow(boolean f) {
        follow = f;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (follow && track != null && track.pointCount() > 0) {
            Track.Point p = track.current();
            centerX = p.x;
            centerY = p.y;
        }
        drawMap(canvas, getWidth(), getHeight(), scale, centerX, centerY, true);
    }

    /** Renders the whole track fitted into a w x h bitmap (for export). */
    public Bitmap renderFit(int w, int h) {
        double minX = 0, maxX = 0, minY = 0, maxY = 0;
        if (track != null && track.pointCount() > 0) {
            List<Track.Point> pts = track.points();
            minX = maxX = pts.get(0).x;
            minY = maxY = pts.get(0).y;
            for (Track.Point p : pts) {
                minX = Math.min(minX, p.x);
                maxX = Math.max(maxX, p.x);
                minY = Math.min(minY, p.y);
                maxY = Math.max(maxY, p.y);
            }
        }
        double spanX = Math.max(maxX - minX, 5.0);
        double spanY = Math.max(maxY - minY, 5.0);
        float pad = 80f;
        float s = (float) Math.min((w - 2 * pad) / spanX, (h - 2 * pad) / spanY);
        s = Math.min(s, 100f);
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        drawMap(c, w, h, s, (minX + maxX) / 2, (minY + maxY) / 2, false);
        return bmp;
    }

    private void drawMap(Canvas c, int w, int h, float s, double cx, double cy, boolean live) {
        c.drawColor(Color.BLACK);
        drawGrid(c, w, h, s, cx, cy);
        if (track == null || track.pointCount() == 0) return;

        List<Track.Point> pts = track.points();
        Path path = new Path();
        for (int i = 0; i < pts.size(); i++) {
            float sx = toScreenX(pts.get(i).x, w, s, cx);
            float sy = toScreenY(pts.get(i).y, h, s, cy);
            if (i == 0) path.moveTo(sx, sy);
            else path.lineTo(sx, sy);
        }
        c.drawPath(path, pathPaint);

        Track.Point cur = track.current();
        float curX = toScreenX(cur.x, w, s, cx);
        float curY = toScreenY(cur.y, h, s, cy);

        if (live && pts.size() > 1) {
            Path back = new Path();
            back.moveTo(curX, curY);
            back.lineTo(toScreenX(0, w, s, cx), toScreenY(0, h, s, cy));
            c.drawPath(back, dashPaint);
        }

        for (Track.Mark m : track.marks()) {
            Track.Point p = track.markPosition(m);
            float mx = toScreenX(p.x, w, s, cx);
            float my = toScreenY(p.y, h, s, cy);
            int color = markColor(m.label);
            dotPaint.setColor(color);
            dotPaint.setStyle(Paint.Style.FILL);
            c.drawCircle(mx, my, 6f * density, dotPaint);
            textPaint.setColor(color);
            c.drawText(m.label, mx + 10f * density, my - 8f * density, textPaint);
        }

        dotPaint.setColor(Color.WHITE);
        dotPaint.setStyle(Paint.Style.FILL);
        c.drawCircle(curX, curY, 6f * density, dotPaint);
        if (live && !Double.isNaN(liveHeadingMap)) {
            float len = 26f * density;
            float tipX = curX + (float) (len * Math.sin(liveHeadingMap));
            float tipY = curY - (float) (len * Math.cos(liveHeadingMap));
            barPaint.setColor(Color.WHITE);
            c.drawLine(curX, curY, tipX, tipY, barPaint);
            c.drawCircle(tipX, tipY, 3f * density, dotPaint);
        }
        drawScaleBar(c, h, s);
    }

    private static int markColor(String label) {
        if ("Вход".equals(label)) return 0xFF00E5FF;
        if ("Опасно".equals(label)) return 0xFFFF3B30;
        return 0xFFFFD60A;
    }

    private void drawGrid(Canvas c, int w, int h, float s, double cx, double cy) {
        double step = NICE_METERS[NICE_METERS.length - 1];
        for (double m : NICE_METERS) {
            if (m * s >= 48f * density) {
                step = m;
                break;
            }
        }
        double minX = cx - (w / 2.0) / s;
        double maxX = cx + (w / 2.0) / s;
        double minY = cy - (h / 2.0) / s;
        double maxY = cy + (h / 2.0) / s;
        for (double x = Math.floor(minX / step) * step; x <= maxX; x += step) {
            float sx = toScreenX(x, w, s, cx);
            c.drawLine(sx, 0, sx, h, gridPaint);
        }
        for (double y = Math.floor(minY / step) * step; y <= maxY; y += step) {
            float sy = toScreenY(y, h, s, cy);
            c.drawLine(0, sy, w, sy, gridPaint);
        }
    }

    private void drawScaleBar(Canvas c, int h, float s) {
        double len = NICE_METERS[0];
        for (double m : NICE_METERS) {
            if (m * s <= 140f * density) len = m;
        }
        float x0 = 16f * density;
        float y0 = h - 22f * density;
        float x1 = x0 + (float) (len * s);
        barPaint.setColor(Color.WHITE);
        c.drawLine(x0, y0, x1, y0, barPaint);
        c.drawLine(x0, y0 - 5f * density, x0, y0 + 5f * density, barPaint);
        c.drawLine(x1, y0 - 5f * density, x1, y0 + 5f * density, barPaint);
        textPaint.setColor(Color.WHITE);
        c.drawText(String.format(Locale.ROOT, "%.0f м", len), x0, y0 - 10f * density, textPaint);
    }

    private static float toScreenX(double x, int w, float s, double cx) {
        return (float) (w / 2.0 + (x - cx) * s);
    }

    private static float toScreenY(double y, int h, float s, double cy) {
        return (float) (h / 2.0 - (y - cy) * s);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        scaleDetector.onTouchEvent(e);
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lastTouchX = e.getX();
                lastTouchY = e.getY();
                break;
            case MotionEvent.ACTION_POINTER_DOWN:
                lastTouchX = e.getX(0);
                lastTouchY = e.getY(0);
                break;
            case MotionEvent.ACTION_POINTER_UP: {
                int remaining = e.getActionIndex() == 0 ? 1 : 0;
                lastTouchX = e.getX(remaining);
                lastTouchY = e.getY(remaining);
                break;
            }
            case MotionEvent.ACTION_MOVE:
                if (e.getPointerCount() == 1 && !scaleDetector.isInProgress()) {
                    float dx = e.getX() - lastTouchX;
                    float dy = e.getY() - lastTouchY;
                    lastTouchX = e.getX();
                    lastTouchY = e.getY();
                    if (dx != 0f || dy != 0f) {
                        follow = false;
                        centerX -= dx / scale;
                        centerY += dy / scale;
                        invalidate();
                    }
                }
                break;
            default:
                break;
        }
        return true;
    }
}
