package app.bunkermap.core;

/**
 * Counts steps from raw accelerometer samples (including gravity). Orientation-independent: it works on the
 * magnitude only. Thresholds are UNCALIBRATED defaults and must be tuned on a real walk.
 */
public final class StepDetector {
    private static final double GRAVITY_TAU_S = 1.5;
    private static final double SMOOTH_TAU_S = 0.06;
    private static final double MAX_GAP_S = 1.0;

    private final double thresholdMs2;
    private final long minIntervalNs;

    private boolean initialized;
    private long lastSampleNs;
    private double gravity;
    private double smooth;
    private boolean armed;
    private boolean hasStep;
    private long lastStepNs;

    public StepDetector(double thresholdMs2, long minIntervalMs) {
        if (!(thresholdMs2 > 0) || minIntervalMs < 0) throw new IllegalArgumentException("bad step detector parameters");
        this.thresholdMs2 = thresholdMs2;
        this.minIntervalNs = minIntervalMs * 1_000_000L;
    }

    public void reset() {
        initialized = false;
        smooth = 0;
        armed = false;
        hasStep = false;
    }

    /** @return true when this sample completes a step. */
    public boolean feed(long timestampNs, double ax, double ay, double az) {
        double m = Math.sqrt(ax * ax + ay * ay + az * az);
        if (!Double.isFinite(m)) return false;
        if (!initialized) {
            initialized = true;
            gravity = m;
            smooth = 0;
            armed = false;
            lastSampleNs = timestampNs;
            return false;
        }
        double dt = (timestampNs - lastSampleNs) * 1e-9;
        if (dt <= 0) return false;
        lastSampleNs = timestampNs;
        if (dt > MAX_GAP_S) {
            gravity = m;
            smooth = 0;
            armed = false;
            return false;
        }
        gravity += (m - gravity) * Math.min(1.0, dt / GRAVITY_TAU_S);
        double dyn = m - gravity;
        smooth += (dyn - smooth) * Math.min(1.0, dt / SMOOTH_TAU_S);

        if (armed) {
            boolean spaced = !hasStep || (timestampNs - lastStepNs) >= minIntervalNs;
            if (smooth > thresholdMs2 && spaced) {
                armed = false;
                hasStep = true;
                lastStepNs = timestampNs;
                return true;
            }
        } else if (smooth < thresholdMs2 * 0.3) {
            armed = true;
        }
        return false;
    }
}
