package app.bunkermap;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.text.InputFilter;
import android.text.InputType;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import app.bunkermap.core.HeadingMath;
import app.bunkermap.core.StepDetector;
import app.bunkermap.core.Track;

public class MainActivity extends Activity implements SensorEventListener {
    // UNCALIBRATED defaults: tune on a real walk with the phone held the way you will hold it underground.
    private static final double STEP_THRESHOLD_MS2 = 1.2;
    private static final long STEP_MIN_INTERVAL_MS = 300;

    private static final String[] MARK_PRESETS = {"Развилка", "Дверь", "Вода", "Опасно", "Лестница", "Тупик"};

    private final Track track = new Track();
    private final StepDetector stepDetector = new StepDetector(STEP_THRESHOLD_MS2, STEP_MIN_INTERVAL_MS);
    private final float[] rot = new float[9];

    private SensorManager sensorManager;
    private Sensor accelSensor;
    private Sensor rotSensor;
    private boolean magnetometerHeading;
    private boolean haveRot;
    private boolean recording;
    private boolean interrupted;
    private int droppedSteps;
    private double liveHeadingMap = Double.NaN;
    private long lastUiMs;

    private MapView mapView;
    private TextView hud;
    private Button btnStart;
    private Button btnStepLen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accelSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        rotSensor = sensorManager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR);
        if (rotSensor == null) {
            rotSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
            magnetometerHeading = rotSensor != null;
        }

        buildUi();
        updateButtons();
        updateHud();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);

        hud = new TextView(this);
        hud.setTextColor(Color.WHITE);
        hud.setTextSize(15);
        hud.setTypeface(Typeface.MONOSPACE);
        hud.setPadding(dp(8), dp(8), dp(8), dp(8));
        root.addView(hud, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        mapView = new MapView(this);
        mapView.setTrack(track);
        root.addView(mapView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        btnStart = makeButton("Старт", v -> toggleRecording());
        Button btnMark = makeButton("Метка", v -> showMarkDialog());
        Button btnCenter = makeButton("Центр", v -> mapView.setFollow(true));
        Button btnSave = makeButton("Сохранить", v -> saveMap());
        btnStepLen = makeButton("Шаг", v -> showStepLengthDialog());
        Button btnClose = makeButton("Я у входа", v -> confirmCloseLoop());
        Button btnReset = makeButton("Сброс", v -> confirmReset());

        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        root.addView(makeRow(btnStart, btnMark, btnCenter, btnSave), rowParams);
        root.addView(makeRow(btnStepLen, btnClose, btnReset), rowParams);

        setContentView(root);
    }

    private Button makeButton(String text, View.OnClickListener listener) {
        Button bt = new Button(this);
        bt.setText(text);
        bt.setAllCaps(false);
        bt.setTextSize(13);
        bt.setOnClickListener(listener);
        return bt;
    }

    private LinearLayout makeRow(Button... buttons) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        for (Button bt : buttons) {
            row.addView(bt, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        }
        return row;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean ok = true;
        if (accelSensor != null) {
            ok &= sensorManager.registerListener(this, accelSensor, SensorManager.SENSOR_DELAY_GAME);
        }
        if (rotSensor != null) {
            ok &= sensorManager.registerListener(this, rotSensor, SensorManager.SENSOR_DELAY_GAME);
        }
        if (!ok) toast("Не удалось подключить датчики");
        if (interrupted) {
            toast("Приложение сворачивалось: шаги не писались, курс мог сбиться. Жми «Продолжить» только если помнишь, где ты.");
        }
        updateButtons();
        updateHud();
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
        haveRot = false;
        if (recording) {
            recording = false;
            interrupted = true;
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        int type = event.sensor.getType();
        if (type == Sensor.TYPE_ACCELEROMETER) {
            if (recording && haveRot
                    && stepDetector.feed(event.timestamp, event.values[0], event.values[1], event.values[2])) {
                onStep();
            }
        } else if (type == Sensor.TYPE_GAME_ROTATION_VECTOR || type == Sensor.TYPE_ROTATION_VECTOR) {
            SensorManager.getRotationMatrixFromVector(rot, event.values);
            haveRot = true;
            double h = HeadingMath.heading(rot);
            liveHeadingMap = (track.hasStarted() && !Double.isNaN(h)) ? track.toMapHeading(h) : Double.NaN;
            mapView.setLiveHeading(liveHeadingMap);
            long now = SystemClock.uptimeMillis();
            if (now - lastUiMs > 100) {
                lastUiMs = now;
                mapView.invalidate();
                updateHud();
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Not used.
    }

    private void onStep() {
        double h = HeadingMath.heading(rot);
        if (!track.addStep(h)) {
            droppedSteps++;
            return;
        }
        mapView.invalidate();
        updateHud();
    }

    private void toggleRecording() {
        if (recording) {
            recording = false;
        } else if (track.hasStarted()) {
            stepDetector.reset();
            recording = true;
        } else {
            if (accelSensor == null || rotSensor == null) {
                toast("На этом телефоне нет нужных датчиков");
                return;
            }
            double h = HeadingMath.heading(rot);
            if (!haveRot || Double.isNaN(h)) {
                toast("Держи телефон перед собой экраном к себе и подожди секунду");
                return;
            }
            track.start(h);
            stepDetector.reset();
            interrupted = false;
            droppedSteps = 0;
            recording = true;
            mapView.setFollow(true);
        }
        updateButtons();
        updateHud();
        mapView.invalidate();
    }

    private void showMarkDialog() {
        if (!track.hasStarted()) {
            toast("Сначала жми Старт у входа");
            return;
        }
        final String[] items = new String[MARK_PRESETS.length + 1];
        System.arraycopy(MARK_PRESETS, 0, items, 0, MARK_PRESETS.length);
        items[MARK_PRESETS.length] = "Своя подпись…";
        new AlertDialog.Builder(this)
                .setTitle("Метка здесь")
                .setItems(items, (dialog, which) -> {
                    if (which == MARK_PRESETS.length) {
                        askCustomMark();
                    } else {
                        track.addMark(MARK_PRESETS[which]);
                        mapView.invalidate();
                    }
                })
                .show();
    }

    private void askCustomMark() {
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(24)});
        new AlertDialog.Builder(this)
                .setTitle("Подпись метки")
                .setView(input)
                .setPositiveButton("OK", (dialog, which) -> {
                    String text = input.getText().toString().trim();
                    if (!text.isEmpty()) {
                        track.addMark(text);
                        mapView.invalidate();
                    }
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    private void showStepLengthDialog() {
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setText(String.valueOf(Math.round(track.getStepLengthM() * 100)));
        new AlertDialog.Builder(this)
                .setTitle("Длина шага, см (30–120)")
                .setMessage("Пройди известное расстояние и посчитай шаги по счётчику сверху: длина шага = расстояние / шаги. Новая длина действует только на следующие шаги.")
                .setView(input)
                .setPositiveButton("OK", (dialog, which) -> {
                    try {
                        int cm = Integer.parseInt(input.getText().toString().trim());
                        if (cm < 30 || cm > 120) throw new NumberFormatException("range");
                        track.setStepLengthM(cm / 100.0);
                        updateButtons();
                    } catch (NumberFormatException e) {
                        toast("Нужно число от 30 до 120");
                    }
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    private void confirmCloseLoop() {
        if (!track.hasStarted() || track.pointCount() < 2) {
            toast("Пока нечего замыкать");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Ты стоишь у входа?")
                .setMessage("Накопившаяся ошибка (на сколько точка конца ушла от входа) равномерно размажется по всему пути, и конец встанет ровно на вход. Грубо, но убирает перекос.")
                .setPositiveButton("Да, замкнуть", (dialog, which) -> {
                    track.closeLoop();
                    mapView.invalidate();
                    updateHud();
                })
                .setNegativeButton("Нет", null)
                .show();
    }

    private void confirmReset() {
        if (!track.hasStarted()) return;
        new AlertDialog.Builder(this)
                .setTitle("Стереть карту?")
                .setMessage("Если не сохранял, пропадёт всё.")
                .setPositiveButton("Стереть", (dialog, which) -> {
                    recording = false;
                    track.clear();
                    interrupted = false;
                    droppedSteps = 0;
                    updateButtons();
                    updateHud();
                    mapView.invalidate();
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    private void saveMap() {
        if (!track.hasStarted() || track.pointCount() < 2) {
            toast("Пока нечего сохранять");
            return;
        }
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ROOT).format(new Date());
        try {
            Bitmap bmp = mapView.renderFit(1440, 1440);
            ByteArrayOutputStream png = new ByteArrayOutputStream();
            boolean encoded = bmp.compress(Bitmap.CompressFormat.PNG, 100, png);
            bmp.recycle();
            if (!encoded) throw new IOException("PNG encoding failed");
            writeToMediaStore(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "bunker_" + stamp + ".png",
                    "image/png", Environment.DIRECTORY_PICTURES + "/BunkerMap", png.toByteArray());
            writeToMediaStore(MediaStore.Downloads.EXTERNAL_CONTENT_URI, "bunker_" + stamp + ".json",
                    "application/json", Environment.DIRECTORY_DOWNLOADS + "/BunkerMap",
                    track.toJson().getBytes(StandardCharsets.UTF_8));
            toast("Сохранено: Pictures/BunkerMap (картинка) и Download/BunkerMap (данные)");
        } catch (IOException | RuntimeException e) {
            toast("Не сохранилось: " + e.getMessage());
        }
    }

    private void writeToMediaStore(Uri collection, String name, String mime, String relativePath, byte[] data)
            throws IOException {
        ContentResolver resolver = getContentResolver();
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath);
        values.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri uri = resolver.insert(collection, values);
        if (uri == null) throw new IOException("MediaStore insert returned null");
        try (OutputStream out = resolver.openOutputStream(uri)) {
            if (out == null) throw new IOException("no output stream for " + name);
            out.write(data);
        } catch (IOException e) {
            resolver.delete(uri, null, null);
            throw e;
        }
        ContentValues done = new ContentValues();
        done.put(MediaStore.MediaColumns.IS_PENDING, 0);
        resolver.update(uri, done, null, null);
    }

    private void updateButtons() {
        btnStart.setText(recording ? "Пауза" : (track.hasStarted() ? "Продолжить" : "Старт"));
        btnStepLen.setText("Шаг " + Math.round(track.getStepLengthM() * 100) + " см");
    }

    private void updateHud() {
        StringBuilder sb = new StringBuilder();
        if (recording) {
            sb.append("ЗАПИСЬ");
        } else if (track.hasStarted()) {
            sb.append("ПАУЗА");
        } else {
            sb.append("Встань у входа, держи телефон перед собой, жми Старт");
        }
        if (track.hasStarted()) {
            sb.append(String.format(Locale.ROOT, "  шагов: %d  ≈%.0f м\n", track.steps(), track.walkedMeters()));
            sb.append(String.format(Locale.ROOT, "До входа по прямой: %.0f м", track.distanceToStart()));
            if (!Double.isNaN(liveHeadingMap)) {
                int clock = HeadingMath.clockPosition(
                        HeadingMath.wrapPi(track.bearingToStart() - liveHeadingMap));
                sb.append(String.format(Locale.ROOT, ", на %d ч", clock));
            }
        }
        if (accelSensor == null || rotSensor == null) {
            sb.append("\nНЕТ ДАТЧИКОВ: путь считать нечем");
        } else if (magnetometerHeading) {
            sb.append("\nНет гироскопа: курс по компасу, рядом с арматурой он врёт");
        }
        if (interrupted) sb.append("\nБЫЛ ПЕРЕРЫВ: курс мог сбиться");
        if (droppedSteps > 0) sb.append("\nШагов пропущено (курс неясен): ").append(droppedSteps);
        hud.setText(sb.toString());
    }
}
