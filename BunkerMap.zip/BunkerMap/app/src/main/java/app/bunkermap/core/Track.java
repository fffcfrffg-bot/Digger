package app.bunkermap.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Dead-reckoned path. Map frame: meters, x to the right, y up, the entrance is (0,0), and the direction the
 * user faced when recording started points up. No Android imports.
 */
public final class Track {
    public static final class Point {
        public final double x;
        public final double y;

        public Point(double x, double y) {
            this.x = x;
            this.y = y;
        }
    }

    /** A labelled spot; its position is always taken from the path point it was made at. */
    public static final class Mark {
        public final int pointIndex;
        public final String label;

        public Mark(int pointIndex, String label) {
            this.pointIndex = pointIndex;
            this.label = label;
        }
    }

    private final ArrayList<Point> points = new ArrayList<>();
    private final ArrayList<Mark> marks = new ArrayList<>();
    private double stepLengthM = 0.70;
    private double refHeading;
    private int steps;
    private boolean started;

    public boolean hasStarted() {
        return started;
    }

    public int pointCount() {
        return points.size();
    }

    public int steps() {
        return steps;
    }

    public double getStepLengthM() {
        return stepLengthM;
    }

    public void setStepLengthM(double meters) {
        if (!(meters >= 0.2 && meters <= 1.5)) throw new IllegalArgumentException("step length out of range");
        stepLengthM = meters;
    }

    public List<Point> points() {
        return Collections.unmodifiableList(points);
    }

    public List<Mark> marks() {
        return Collections.unmodifiableList(marks);
    }

    public Point current() {
        return points.isEmpty() ? null : points.get(points.size() - 1);
    }

    public Point markPosition(Mark m) {
        return points.get(m.pointIndex);
    }

    public void clear() {
        points.clear();
        marks.clear();
        steps = 0;
        started = false;
    }

    /** Starts a new track at the entrance; headingRad is the current world heading and becomes "up" on the map. */
    public void start(double headingRad) {
        if (!Double.isFinite(headingRad)) throw new IllegalArgumentException("heading must be finite");
        clear();
        refHeading = headingRad;
        points.add(new Point(0, 0));
        marks.add(new Mark(0, "Вход"));
        started = true;
    }

    /** Heading in the map frame (clockwise from up) for a world heading. */
    public double toMapHeading(double worldHeadingRad) {
        return HeadingMath.wrapPi(worldHeadingRad - refHeading);
    }

    /** @return false if the step was ignored (not started or heading not finite). */
    public boolean addStep(double worldHeadingRad) {
        if (!started || !Double.isFinite(worldHeadingRad)) return false;
        double h = worldHeadingRad - refHeading;
        Point p = points.get(points.size() - 1);
        points.add(new Point(p.x + stepLengthM * Math.sin(h), p.y + stepLengthM * Math.cos(h)));
        steps++;
        return true;
    }

    public void addMark(String label) {
        if (!started) return;
        marks.add(new Mark(points.size() - 1, label));
    }

    public double distanceToStart() {
        Point c = current();
        return c == null ? 0 : Math.hypot(c.x, c.y);
    }

    /** Direction from the current position to the entrance, radians clockwise from map up. */
    public double bearingToStart() {
        Point c = current();
        if (c == null || Math.hypot(c.x, c.y) < 1e-9) return 0;
        return Math.atan2(-c.x, -c.y);
    }

    public double walkedMeters() {
        double sum = 0;
        for (int i = 1; i < points.size(); i++) {
            sum += Math.hypot(points.get(i).x - points.get(i - 1).x, points.get(i).y - points.get(i - 1).y);
        }
        return sum;
    }

    /**
     * The user says they are standing at the entrance again: the accumulated error (current position minus the
     * entrance) is spread linearly along the path so the end lands exactly on the entrance. Crude: it assumes the
     * drift grew evenly with the number of steps.
     */
    public void closeLoop() {
        int n = points.size();
        if (n < 2) return;
        Point last = points.get(n - 1);
        double ex = last.x;
        double ey = last.y;
        for (int i = 0; i < n; i++) {
            double f = (double) i / (n - 1);
            Point p = points.get(i);
            points.set(i, new Point(p.x - ex * f, p.y - ey * f));
        }
    }

    public String toJson() {
        StringBuilder sb = new StringBuilder(64 + points.size() * 24);
        sb.append("{\"version\":1,");
        sb.append("\"frame\":\"meters; x right, y up; entrance at 0,0; initial facing direction is up\",");
        sb.append(String.format(Locale.ROOT, "\"stepLengthM\":%.3f,\"steps\":%d,", stepLengthM, steps));
        sb.append("\"points\":[");
        for (int i = 0; i < points.size(); i++) {
            if (i > 0) sb.append(',');
            Point p = points.get(i);
            sb.append(String.format(Locale.ROOT, "[%.3f,%.3f]", p.x, p.y));
        }
        sb.append("],\"marks\":[");
        for (int i = 0; i < marks.size(); i++) {
            if (i > 0) sb.append(',');
            Mark m = marks.get(i);
            Point p = points.get(m.pointIndex);
            sb.append(String.format(Locale.ROOT, "{\"pointIndex\":%d,\"x\":%.3f,\"y\":%.3f,\"label\":", m.pointIndex, p.x, p.y));
            appendJsonString(sb, m.label);
            sb.append('}');
        }
        sb.append("]}");
        return sb.toString();
    }

    private static void appendJsonString(StringBuilder sb, String s) {
        sb.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '"') sb.append("\\\"");
            else if (c == '\\') sb.append("\\\\");
            else if (c < 0x20) sb.append(String.format(Locale.ROOT, "\\u%04x", (int) c));
            else sb.append(c);
        }
        sb.append('"');
    }
}
